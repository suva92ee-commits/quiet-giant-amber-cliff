Suvadeep Mallik — Audio Portfolio

Play the MP3 files in /audio, or open the PDF in Adobe Acrobat and use the paperclip/attachments panel.
Browser PDF viewers usually cannot play embedded audio.

  hi-broadcast.mp3  — Broadcast Hindi — formal studio read
  hi-conversational.mp3  — Conversational Hindi — humanised, fillers kept
  hi-live-field.mp3  — Field / live judgement — Eastern Hindi
  hi-codeswitch.mp3  — Hindi–English technical mix
  hi-prosody.mp3  — Emotion, breath, lower energy
  hi-question.mp3  — Interrogative contour
  hi-accent-east.mp3  — Eastern Hindi ear — dialect as feature
  hi-everyday-female.mp3  — Everyday Hindi, second speaker
  hi-dialogue-qc.mp3  — Two-engineer QC dialogue
  hi-session-log.mp3  — Session slate — numbers and entities
  en-studio.mp3  — English studio read (B2+)
  en-judgment.mp3  — Ambiguous-take decision, spoken
  hi-live-field-raw.mp3  — Field capture untreated (rumble)
  hi-live-field-restored.mp3  — After a conservative RX-style pass
